﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalesManagementComponent
{
    /// <summary>
    /// Interaction logic for SellCarToNewCustomer.xaml
    /// </summary>
    public partial class SellCarToNewCustomer : Window
    {
        public SellCarToNewCustomer()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            System.Windows.Data.CollectionViewSource customerViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("customerViewSource")));
            // Load data by setting the CollectionViewSource.Source property:
            // customerViewSource.Source = [generic data source]
            System.Windows.Data.CollectionViewSource individualCarViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("individualCarViewSource")));
            // Load data by setting the CollectionViewSource.Source property:
            // individualCarViewSource.Source = [generic data source]
            System.Windows.Data.CollectionViewSource cars_SoldViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("cars_SoldViewSource")));
            // Load data by setting the CollectionViewSource.Source property:
            // cars_SoldViewSource.Source = [generic data source]
        }

        private void btnSell_Click(object sender, RoutedEventArgs e)
        {
            string output = Validation.validEmptyFields(grid);
            if (output != null)
            {
                MessageBox.Show(output);
            }
            else
            {
                Con ctx = new Con();
                Person p = new Person();
                p.Address = addressTextBox.Text;
                p.Name = nameTextBox.Text;
                p.Telephone = telephoneTextBox.Text;

                Customer c = new Customer();
                c.Licence_Number = licence_NumberTextBox.Text;
                c.Age = float.Parse(ageTextBox.Text);
                c.License_Expiry_Date = license_Expiry_DateDatePicker.SelectedDate.GetValueOrDefault();

                int icid = int.Parse(carIDTextBox.Text);

                IndividualCar ic = ctx.IndividualCars.Where(i => i.CarID == icid).FirstOrDefault();

                ic.Status = "Sold";

                Cars_Sold cs = new Cars_Sold();
                cs.Sale_Price = int.Parse(sale_PriceTextBox.Text);
                cs.Date_Sold = DateTime.Now;

                p.Customer = c;
                ctx.Cars_Sold.Add(cs);
                ctx.People.Add(p);
                ctx.Customers.Add(c);
                ctx.SaveChanges();
                MessageBox.Show("Customer Added and Car Successfully Sold");
            }
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow form = new MainWindow();
            form.Show();
            this.Hide();
        }
    }
}

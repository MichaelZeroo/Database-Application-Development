﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesManagementComponent
{
    class DataStore
    {
       
        static public Employee currentLogin = null;
        static public Employee getLoginDetail(String un, String pwd)
        {
            using (Con ctx = new Con())
            {
                currentLogin = ctx.Employees.Where(p => p.Username == un && p.Password == pwd).FirstOrDefault();
            }
            return currentLogin;
        }
    }
}

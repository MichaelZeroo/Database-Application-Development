﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalesManagementComponent
{
    /// <summary>
    /// Interaction logic for SellCarToExistingCustomer.xaml
    /// </summary>
    public partial class SellCarToExistingCustomer : Window
    {
        public SellCarToExistingCustomer()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            System.Windows.Data.CollectionViewSource customerViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("customerViewSource")));
            // Load data by setting the CollectionViewSource.Source property:
            // customerViewSource.Source = [generic data source]
            System.Windows.Data.CollectionViewSource cars_SoldViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("cars_SoldViewSource")));
            // Load data by setting the CollectionViewSource.Source property:
            // cars_SoldViewSource.Source = [generic data source]
            System.Windows.Data.CollectionViewSource individualCarViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("individualCarViewSource")));
            // Load data by setting the CollectionViewSource.Source property:
            // individualCarViewSource.Source = [generic data source]
        }

        private void btnSell_Click(object sender, RoutedEventArgs e)
        {
            string output = Validation.validEmptyFields(grid1);
            if (output != null)
            {
                MessageBox.Show(output);
            }
            else
            {
                Con ctx = new Con();
                int cid = int.Parse(customerIDTextBox.Text);
                int carid = int.Parse(carIDTextBox.Text);

                Customer cust = ctx.Customers.Where(c => c.CustomerID == cid).FirstOrDefault();
                IndividualCar ic = ctx.IndividualCars.Where(i => i.CarID == carid).FirstOrDefault();

                Cars_Sold cs = new Cars_Sold();

                cs.IndividualCar = ic;
                cs.Customer = cust;
                cs.Sale_Price = int.Parse(sale_PriceTextBox.Text);
                ic.Status = "Sold";
                cs.Date_Sold = DateTime.Now;

                ctx.Cars_Sold.Add(cs);
                ctx.SaveChanges();
                MessageBox.Show("Car Successfully Sold");
            }
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow form = new MainWindow();
            form.Show();
            this.Hide();
        }
    }
}

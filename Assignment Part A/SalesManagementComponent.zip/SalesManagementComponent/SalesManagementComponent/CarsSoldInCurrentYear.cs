﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesManagementComponent
{
    class CarsSoldInCurrentYear
    {
        public int Car_Sold_ID { get; set; }
        public int Car_For_Sale_Id { get; set; }
        public int Customer_Id { get; set; }
        public decimal Sale_Price { get; set; }
        public DateTime Date_Sold { get; set; }
    }
}

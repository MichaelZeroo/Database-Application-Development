﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesManagementComponent
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ECItem_Click(object sender, RoutedEventArgs e)
        {
            SellCarToExistingCustomer form = new SellCarToExistingCustomer();
            form.Show();
            this.Hide();
        }

        private void NCItem_Click(object sender, RoutedEventArgs e)
        {
            SellCarToNewCustomer form = new SellCarToNewCustomer();
            form.Show();
            this.Hide();
        }

        private void CSCItem_Click(object sender, RoutedEventArgs e)
        {
            ShowCarsSoldToACustomer form = new ShowCarsSoldToACustomer();
            form.Show();
            this.Hide();
        }

        private void CSBDItem_Click(object sender, RoutedEventArgs e)
        {
            CarsSoldBetweenTwoDates form = new CarsSoldBetweenTwoDates();
            form.Show();
            this.Hide();
        }

        private void CSAPItem_Click(object sender, RoutedEventArgs e)
        {
            ShowCarsSoldInCurrentYear form = new ShowCarsSoldInCurrentYear();
            form.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            Login form = new Login();
            form.Show();
            this.Hide();
        }
    }
}

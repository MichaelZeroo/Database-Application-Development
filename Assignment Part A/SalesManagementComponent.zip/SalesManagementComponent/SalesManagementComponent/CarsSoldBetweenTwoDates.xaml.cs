﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalesManagementComponent
{
    /// <summary>
    /// Interaction logic for CarsSoldBetweenTwoDates.xaml
    /// </summary>
    public partial class CarsSoldBetweenTwoDates : Window
    {
        public CarsSoldBetweenTwoDates()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            System.Windows.Data.CollectionViewSource cars_SoldViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("cars_SoldViewSource")));
            // Load data by setting the CollectionViewSource.Source property:
            // cars_SoldViewSource.Source = [generic data source]
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            Con ctx = new Con();

            cars_SoldDataGrid.ItemsSource = ctx.Cars_Sold.Where(p => p.Date_Sold >= DatePicker1.SelectedDate && p.Date_Sold <= DatePicker2.SelectedDate).ToList();
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow form = new MainWindow();
            form.Show();
            this.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalesManagementComponent
{
    /// <summary>
    /// Interaction logic for ShowCarsSoldInCurrentYear.xaml
    /// </summary>
    public partial class ShowCarsSoldInCurrentYear : Window
    {
        public ShowCarsSoldInCurrentYear()
        {
            InitializeComponent();
            Con ctx = new Con();
            DataGrid.ItemsSource = ctx.Database.SqlQuery<CarsSoldInCurrentYear>("select cs.Car_Sold_ID, cs.Car_For_Sale_Id, cs.Customer_Id, cs.Sale_Price, cs.Date_Sold from Cars_Sold cs where YEAR(Date_Sold) = YEAR(GETDATE())").ToList();
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow form = new MainWindow();
            form.Show();
            this.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalesManagementComponent
{
    /// <summary>
    /// Interaction logic for ShowCarsSoldToACustomer.xaml
    /// </summary>
    public partial class ShowCarsSoldToACustomer : Window
    {
        System.Windows.Data.CollectionViewSource cars_SoldViewSource = null;
        Con ctx = new Con();
        public ShowCarsSoldToACustomer()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            cars_SoldViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("cars_SoldViewSource")));
            // Load data by setting the CollectionViewSource.Source property:
            // cars_SoldViewSource.Source = [generic data source]
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string output = Validation.validEmptyFields(grid);
            if (output != null)
            {
                MessageBox.Show(output);
            }
            else
            {
                int id = int.Parse(txtSearchID.Text);
                cars_SoldViewSource.Source = ctx.Cars_Sold.Where(p => p.Customer_Id == id).ToList();
            }


                       
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow form = new MainWindow();
            form.Show();
            this.Hide();
        }
    }
}
